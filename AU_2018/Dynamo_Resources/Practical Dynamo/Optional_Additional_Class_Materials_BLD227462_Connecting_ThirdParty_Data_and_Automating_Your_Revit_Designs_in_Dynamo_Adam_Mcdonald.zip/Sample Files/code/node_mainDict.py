# -*- coding: utf-8 -*-
"""
This is the custom node to grab the plan, floor, and room level attributes
"""

#%%
#This section contains the important imports to make the code work
#Use this section if you are coding this in a Python IDE

#import xml.etree.ElementTree as etree # Import ElementTree, which parses the XML

#%%
#This section contains the important imports to make the code work
#Use this section if you are coding this in Dynamo

import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *
import sys
sys.path.append("C:\Program Files (x86)\IronPython 2.7\Lib")
import xml.etree.ElementTree as etree # Import ElementTree, which parses the XML

#%%
#Parse the XML from IN variable filepath
#This is if you are coding this in a Python IDE

#inputFilePath = 'C:/Users/svensop/Documents/au - buildchange/code/' #File Address
#inputFile = 'Toms House-ver2.magicplan'
#tree = etree.parse(inputFilePath+inputFile) # Parse XML to Create Tree
#root = tree.getroot() # Get Root Structure

#%%
#Parse the XML from IN variable filepath
#This is for handling the data input in Dynamo

dataEnteringNode = IN[0] 
tree = etree.parse(dataEnteringNode) # Parse XML to Create Tree

root = tree.getroot() # Get Root Structure

#%%
#This section is critical to creating wall keys (concatenation: floorType_xcoordinate_ycoordinate); 
#exploded coordinates come through with 3 point precision

import decimal

# relative coordinates come through with 5 point precision, so add 1 to mitigate roundoff error
decimal.getcontext().prec = 6
# the absolute coordinates appear to be calculated with this rule in mind
decimal.getcontext().rounding = 'ROUND_HALF_DOWN'

#%%

planDict = {}
floorDict = {}
roomDict = {}

planDict = root.attrib

for values in root.findall('values'):
    for value in values:
        planAttribKey = value.attrib['key']
        planAttribValue = value.text
        planDict[planAttribKey] = planAttribValue


for floor in root.findall('floor'): # Search root for floors to loop through
    floorType = floor.attrib['floorType'] # Grab Floor Name (to be used to create unique identifiers)
    floorUID = floor.attrib['uid'] # Grab floor ID
    floorDict[floorType] = {
            'floorType':floorType,
            'floorUID':floor.attrib['uid']
            }
    for symbols in floor.findall('symbolInstance'):
        if symbols.attrib['id'] == 'floor':
            for values in symbols.findall('values'):
                for value in values:
                    floorAttribKey = value.attrib['key']
                    floorAttribValue = value.text
                    floorDict[floorType][floorAttribKey] = floorAttribValue

    for floorRoom in floor.findall('floorRoom'): #Loop Through Rooms to find room coordinates
        roomID = floorRoom.attrib['uid']
        roomX = decimal.Decimal(floorRoom.attrib['x'])
        roomY = decimal.Decimal(floorRoom.attrib['y'])
        roomDict[roomID] = {
                'type': floorRoom.attrib['type'],
                'centerPoint': (roomX,roomY)
                }
        for values in floorRoom.findall('values'):
            for value in values:
                roomAttribKey = value.attrib['key']
                roomAttribValue = value.text
                roomDict[roomID][roomAttribKey] = roomAttribValue
                
#%%
# Translate dictionary of dictionaries to list of lists for Dynamo
def dofDicts_to_lofLists(d):
    outList=[]
    for keyDict in d.keys():
        mainKey = keyDict
        mainVal = d[mainKey]
        keyList = []
        valueList = []
        for subKey in mainVal.keys():
            subValue = mainVal[subKey]
            keyList.append(subKey)
            valueList.append(subValue)
        outList.append([mainKey, keyList, valueList])
    return outList

#%%
# Create output files
listPlan = [[k for k in planDict.keys()], [v for v in planDict.values()]]
listFloor = dofDicts_to_lofLists(floorDict)
listRoom = dofDicts_to_lofLists(roomDict)

OUT = [listPlan, listFloor, listRoom]