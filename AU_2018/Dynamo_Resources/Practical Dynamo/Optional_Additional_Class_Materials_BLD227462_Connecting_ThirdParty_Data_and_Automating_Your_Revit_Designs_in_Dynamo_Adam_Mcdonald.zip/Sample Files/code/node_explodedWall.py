# -*- coding: utf-8 -*-
"""
This is the custom node to grab the exploded walls from all rooms and floors
"""

#%%
#This section contains the important imports to make the code work
#Use this section if you are coding this in a Python IDE

#import xml.etree.ElementTree as etree # Import ElementTree, which parses the XML

#%%
#This section contains the important imports to make the code work
#Use this section if you are coding this in Dynamo

import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *
import sys
sys.path.append("C:\Program Files (x86)\IronPython 2.7\Lib")
import xml.etree.ElementTree as etree # Import ElementTree, which parses the XML

#%%
#Parse the XML from IN variable filepath
#This is if you are coding this in a Python IDE

#inputFilePath = 'C:/Users/svensop/Documents/au - buildchange/code/' #File Address
#inputFile = 'Toms House-ver2.magicplan'
#tree = etree.parse(inputFilePath+inputFile) # Parse XML to Create Tree
#root = tree.getroot() # Get Root Structure

#%%
#Parse the XML from IN variable filepath
#This is for handling the data input in Dynamo

dataEnteringNode = IN[0] 
tree = etree.parse(dataEnteringNode) # Parse XML to Create Tree

root = tree.getroot() # Get Root Structure

#%%
#This section is critical to creating wall keys (concatenation: floorType_xcoordinate_ycoordinate); 
#exploded coordinates come through with 3 point precision

import decimal

# relative coordinates come through with 5 point precision, so add 1 to mitigate roundoff error
decimal.getcontext().prec = 6
# the absolute coordinates appear to be calculated with this rule in mind
decimal.getcontext().rounding = 'ROUND_HALF_DOWN'

#%%

explWallDict={} # The exploded wall dictionary (Step 1 in Dynamo Script to create the walls)

for floor in root.findall('floor'): # Search root for floors to loop through
    floorType = floor.attrib['floorType'] # Grab Floor Name (to be used to create unique identifiers)  
        
    ##### POPULATE EXPLODED WALL DICTIONARY #####
    
    explode = floor.find('exploded') # Grab exploded node for the floor
    
    aPointPair = [] # Instantiate to create absolute point pair [floorType, startPoint, endPoint] list
    
    # Loop through each wall level item on the floor to grab start and end points
    for wall in explode.findall('wall'):
        wallPointList = []
        for point in wall.findall('point'):
            wallPointList.append((point.attrib['x'], point.attrib['y']))
                    
        aPointPair.append([floorType, wallPointList[0], wallPointList[1]])
        wallID = str([floorType, wallPointList[0], wallPointList[1]])
        explWallDict[wallID] = {'floor': floorType, 'startPoint':wallPointList[0], 'endPoint': wallPointList[1]}

#%%
# Translate dictionary of dictionaries to list of lists for Dynamo
def dofDicts_to_lofLists(d):
    outList=[]
    for keyDict in d.keys():
        mainKey = keyDict
        mainVal = d[mainKey]
        keyList = []
        valueList = []
        for subKey in mainVal.keys():
            subValue = mainVal[subKey]
            keyList.append(subKey)
            valueList.append(subValue)
        outList.append([mainKey, keyList, valueList])
    return outList

#%%
# Create output files
listExplWall = dofDicts_to_lofLists(explWallDict)
OUT = listExplWall