# -*- coding: utf-8 -*-
"""
This helper function takes an input of:
    1. a list of lists of lists, 
    2. the index for the attribute name list (0, 1, 2,...etc.)
    3. and the index for the value list (0, 1, 2, ...etc.)
    4. a searchString for the attribute you want to grab
And it Returns a list of the values for the searchString attribute from the entire list
"""

#%%
#This section contains the important imports to make the code work
#Use this section if you are coding this in Dynamo

import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *
import sys
sys.path.append("C:\Program Files (x86)\IronPython 2.7\Lib")
import xml.etree.ElementTree as etree # Import ElementTree, which parses the XML

#%%
# This is for handling the data input in Dynamo

data = IN[0]
attributeIndex = IN[1]
valueIndex = IN[2]
searchAttributeString = IN[3]

#%%

def lookupIndexValFromString(inputList, attriIndex, valIndex, searchString):
    lookupIndex = []
    
    for l in inputList:
        search = l[attriIndex]
        index = search.index(searchString) if searchString in search else -1
        lookupIndex.append(index)
    
    resultIndex = []
    
    for i, l in enumerate(inputList):
        result = l[valIndex][lookupIndex[i]] if (lookupIndex[i] >= 0) else ''
        resultIndex.append(result)  
    
    return resultIndex

OUT = lookupIndexValFromString(data, attributeIndex, valueIndex, searchAttributeString)
