# -*- coding: utf-8 -*-
"""
This is the custom node to grab the items (doors, windows, and furniture) and all of their attributes
"""

#%%
#This section contains the important imports to make the code work
#Use this section if you are coding this in a Python IDE

#import xml.etree.ElementTree as etree # Import ElementTree, which parses the XML

#%%
#This section contains the important imports to make the code work
#Use this section if you are coding this in Dynamo

import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *
import sys
sys.path.append("C:\Program Files (x86)\IronPython 2.7\Lib")
import xml.etree.ElementTree as etree # Import ElementTree, which parses the XML

#%%
#Parse the XML from IN variable filepath
# This is if you are coding this in a Python IDE

#inputFilePath = 'C:/Users/svensop/Documents/au - buildchange/code/' #File Address - you'll need to update this
#inputFile = 'Toms House-ver2.magicplan'
#tree = etree.parse(inputFilePath+inputFile) # Parse XML to Create Tree
#root = tree.getroot() # Get Root Structure

#%%
# This is for handling the data input in Dynamo

dataEnteringNode = IN[0] 
tree = etree.parse(dataEnteringNode) # Parse XML to Create Tree

root = tree.getroot() # Get Root Structure

#%%
#This section is critical to creating wall keys (concatenation: floorType_xcoordinate_ycoordinate); 
#exploded coordinates come through with 3 point precision

import decimal

# relative coordinates come through with 5 point precision, so add 1 to mitigate roundoff error
decimal.getcontext().prec = 6
# the absolute coordinates appear to be calculated with this rule in mind
decimal.getcontext().rounding = 'ROUND_HALF_DOWN'

#%%

itemDict={} # The item dictonary with Windows, Doors, and Items (Step 3 in Dynamo Script to place items in the walls)

for floor in root.findall('floor'): # Search root for floors to loop through
    floorType = floor.attrib['floorType'] # Grab Floor Name (to be used to create unique identifiers)
    floorUID = floor.attrib['uid'] # Grab floor ID
    
    explode = floor.find('exploded') # Grab exploded node for the floor
    
    ##### POPULATE ITEM DICTIONARY #####

    # Loop through each exploded door to grab absolute attributes and create key-item dictionary
    for door in explode.findall('door'):
        doorID = str(floorType) + door.attrib['symbolInstance']
        itemDict[doorID] = {
                'itemType':'door', 
                'doorType':door.attrib['type'], 
                'itemStart':(door.attrib['x1'], door.attrib['y1']), 
                'itemEnd':(door.attrib['x2'], door.attrib['y2']), 
                'itemWidth':door.attrib['width'], 
                'itemOrientation':door.attrib['orientation']
                }

    # Loop through each exploded window to grab absolute attributes and create key-item dictionary
    for window in explode.findall('window'):
        windowID = str(floorType) + window.attrib['symbolInstance']
        itemDict[windowID] = {
                'itemType':'window',
                'windowType':window.attrib['type'],
                'itemStart':(window.attrib['x1'], window.attrib['y1']),
                'itemEnd':(window.attrib['x2'], window.attrib['y2']),
                'itemWidth':window.attrib['width'],
                'itemOrientation':window.attrib['orientation']
                }

    # Loop through each exploded furniture to grab absolute attributes and create key-item dictionary
    for furniture in explode.findall('furniture'):
        furnitureID = str(floorType) + furniture.attrib['symbolInstance']
        itemDict[furnitureID] = {
                'itemType':'furniture',
                'furnitureType':furniture.attrib['type'],
                'itemPosition':(furniture.attrib['x'], furniture.attrib['y']),
                'itemAngle':furniture.attrib['angle'],
                'itemWidth':furniture.attrib['width'],
                'itemDepth':furniture.attrib['depth']
                }

    # Loop through each floor item to add symbol to the item dictonary
    for item in floor.findall('symbolInstance'):
        itemID = str(floorType) + item.attrib['id']
        itemSymbol = item.attrib['symbol']
        
        # Collect item Symbol
        if itemID in list(itemDict.keys()):
            itemDict[itemID]['itemSymbol'] = itemSymbol
        
        # Collect Attributes
        for values in item.findall('values'):
            for value in values:
                customAttributeID = value.attrib['key']
                customAttributeValue = value.text
                if itemID in list(itemDict.keys()):
                    itemDict[itemID][customAttributeID] = customAttributeValue
 
    for floorRoom in floor.findall('floorRoom'): #Loop Through Rooms to find room coordinates
        roomID = floorRoom.attrib['uid']
        roomType = floorRoom.attrib['type']
        
        for rDoor in floorRoom.findall('door'):
            rDoorID = str(floorType) + rDoor.attrib['symbolInstance']
            if rDoorID in list(itemDict.keys()):
                itemDict[rDoorID]['snappedHeight'] = rDoor.attrib['snappedHeight']
                
        for rWindow in floorRoom.findall('window'):
            rWindowID = str(floorType) + rWindow.attrib['symbolInstance']
            if rWindowID in list(itemDict.keys()):
                itemDict[rWindowID]['snappedHeight'] = rWindow.attrib['snappedHeight']
                
#%%
# Translate dictionary of dictionaries to list of lists for Dynamo
def dofDicts_to_lofLists(d):
    outList=[]
    for keyDict in d.keys():
        mainKey = keyDict
        mainVal = d[mainKey]
        keyList = []
        valueList = []
        for subKey in mainVal.keys():
            subValue = mainVal[subKey]
            keyList.append(subKey)
            valueList.append(subValue)
        outList.append([mainKey, keyList, valueList])
    return outList

#%%
# Create output files
listItem = dofDicts_to_lofLists(itemDict)
OUT = listItem
