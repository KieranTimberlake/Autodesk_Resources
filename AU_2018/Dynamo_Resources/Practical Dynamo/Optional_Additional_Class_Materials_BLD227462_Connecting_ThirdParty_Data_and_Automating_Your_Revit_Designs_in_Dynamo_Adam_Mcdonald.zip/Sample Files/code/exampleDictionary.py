# -*- coding: utf-8 -*-
"""
Dictionary Example

Let's say we have information on different objects in a room. 
In this example, let's suppose they are all located in a bedroom (called bedroom1). There are
two windows and one door in the bedroom. Let's say we create a key to reference these specific 
objects by concatenating what room they are in and numbering the items.
"""

# We create dictionary objectDict1
objectDict1 = {'bedroom1_window1':'window', 
               'bedroom1_window2': 'window', 
               'bedroom1_door1':'door'}

# We create dictionary objectDict2
objectDict2 = {'bedroom1_window1': {'type':'window', 'width':1, 'length':3, 'height':2}, 
               'bedroom1_window2': {'type':'window', 'width':1.5, 'length':3.5, 'height':2.5}, 
               'bedroom1_door1': {'type':'door', 'width':3, 'length':7, 'height':0}}

print(objectDict1.keys()) # This prints all keys in objectDict1
print(objectDict1.values()) # This prints all values in objectDict1

print(objectDict2.keys()) # This prints all keys in objectDict2
print(objectDict2.values()) # This prints all values in objectDict2
print(objectDict2['bedroom1_window1']) # This retrieves all values associated with bedroom1_window1
print(objectDict2['bedroom1_window1']['type']) # This retrieves what type of object bedroom1_window1 is
print(objectDict2['bedroom1_window1']['width']) # This retrieves the width of bedroom1_window1
print(objectDict2['bedroom1_window2']['length']) # This retrieves the length of bedroom1_window2
print(objectDict2['bedroom1_door1']['height']) # This statement retrieves the height of bedroom1_door1