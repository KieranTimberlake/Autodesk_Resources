Hi,
I could not share the files for the Johnson Controls Shanghai HQ's. Certain Johnson Control data contained in the files along with other Gensler Data is for the reason. I appreciate your patience and understanding in this matter.

Thanks, Jarod Schultz